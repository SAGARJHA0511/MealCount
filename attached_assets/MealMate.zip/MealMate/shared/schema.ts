import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull(), // 'vendor', 'client_admin', 'client_employee'
  vendorId: text("vendor_id"),
  department: text("department"),
  companyName: text("company_name"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  vendorId: true,
  department: true,
  companyName: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const mealPreferences = pgTable("meal_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  preference: text("preference").notNull(), // 'vegetarian', 'non-vegetarian', 'no-meal'
  date: timestamp("date").notNull().defaultNow(),
  couponCode: text("coupon_code").notNull(),
});

export const insertMealPreferenceSchema = createInsertSchema(mealPreferences).pick({
  userId: true,
  preference: true,
  couponCode: true,
});

export type InsertMealPreference = z.infer<typeof insertMealPreferenceSchema>;
export type MealPreference = typeof mealPreferences.$inferSelect;

export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  rating: integer("rating").notNull(),
  mealDate: timestamp("meal_date").notNull(),
  mealType: text("meal_type").notNull(), // 'vegetarian', 'non-vegetarian'
  comments: text("comments"),
  suggestions: text("suggestions"),
  submittedAt: timestamp("submitted_at").notNull().defaultNow(),
});

export const insertFeedbackSchema = createInsertSchema(feedback).pick({
  userId: true,
  rating: true,
  mealDate: true,
  mealType: true,
  comments: true,
  suggestions: true,
});

export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;
export type Feedback = typeof feedback.$inferSelect;

export const weeklyMenus = pgTable("weekly_menus", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull(),
  weekStartDate: timestamp("week_start_date").notNull(),
  menuData: text("menu_data").notNull(), // JSON string with menu details
  uploadedAt: timestamp("uploaded_at").notNull().defaultNow(),
});

export const insertWeeklyMenuSchema = createInsertSchema(weeklyMenus).pick({
  vendorId: true,
  weekStartDate: true,
  menuData: true,
});

export type InsertWeeklyMenu = z.infer<typeof insertWeeklyMenuSchema>;
export type WeeklyMenu = typeof weeklyMenus.$inferSelect;
