import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation } from 'wouter';

// Create context with default values to avoid null checks
const AuthContext = createContext({
  isAuthenticated: false,
  userRole: null,
  user: null,
  loading: true,
  login: () => {},
  logout: () => {},
  register: () => {},
  generateVendorId: () => ''
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userRole, setUserRole] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [location, setLocation] = useLocation();

  // Check if user is already logged in (from localStorage)
  useEffect(() => {
    try {
      const storedUser = localStorage.getItem('mealtrack_user');
      if (storedUser) {
        const parsedUser = JSON.parse(storedUser);
        setUser(parsedUser);
        setUserRole(parsedUser.role);
        setIsAuthenticated(true);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Login function
  const login = (userData) => {
    try {
      // In a real app, this would validate with an API
      const { role, ...rest } = userData;
      
      console.log("Login with role:", role);
      console.log("Login data:", userData);
      
      // Store user data
      const user = { role, ...rest };
      setUser(user);
      setUserRole(role);
      setIsAuthenticated(true);
      
      // Save to localStorage for persistence
      localStorage.setItem('mealtrack_user', JSON.stringify(user));
      
      // Redirect to appropriate dashboard
      console.log(`Redirecting to dashboard: /dashboard/${role}`);
      
      // Use Wouter for navigation
      setTimeout(() => {
        setLocation(`/dashboard/${role}`);
      }, 100);
    } catch (error) {
      console.error("Login error:", error);
    }
  };

  // Logout function
  const logout = () => {
    setUser(null);
    setUserRole(null);
    setIsAuthenticated(false);
    localStorage.removeItem('mealtrack_user');
    setLocation('/');
  };

  // Register function (for mock registration)
  const register = (userData, role) => {
    try {
      // In a real app, this would send data to an API
      console.log("Registering user with role:", role);
      console.log("User data:", userData);
      
      const newUser = {
        ...userData,
        role,
        id: Math.floor(Math.random() * 10000)
      };
      
      // Save to localStorage for persistence
      localStorage.setItem('mealtrack_user', JSON.stringify(newUser));
      
      // Update state
      setUser(newUser);
      setUserRole(role);
      setIsAuthenticated(true);
      
      // Navigate to appropriate dashboard with a small delay to ensure state updates
      console.log("Navigating to dashboard:", `/dashboard/${role}`);
      
      // Use Wouter's setLocation for navigation
      setTimeout(() => {
        setLocation(`/dashboard/${role}`);
      }, 300);
    } catch (error) {
      console.error("Registration error:", error);
      // In case of error, reset state
      setUser(null);
      setUserRole(null);
      setIsAuthenticated(false);
    }
  };

  // Generate vendor ID
  const generateVendorId = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let id = '';
    for (let i = 0; i < 8; i++) {
      id += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return id;
  };

  // Value object to be provided to consumers
  const value = {
    isAuthenticated,
    userRole,
    user,
    loading,
    login,
    logout,
    register,
    generateVendorId
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading ? children : <div>Loading...</div>}
    </AuthContext.Provider>
  );
};
