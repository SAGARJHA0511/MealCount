import { useState, useEffect } from 'react';
import Navbar from '../components/Navbar';
import DateTimeDisplay from '../components/DateTimeDisplay';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const AdminDashboard = () => {
  const { toast } = useToast();
  const [recommendation, setRecommendation] = useState('');
  const [employees, setEmployees] = useState([
    { id: 1, name: 'John Smith', department: 'Engineering', preference: 'vegetarian', submitted: true },
    { id: 2, name: 'Emily Johnson', department: 'Marketing', preference: 'non-vegetarian', submitted: true },
    { id: 3, name: 'David Lee', department: 'Engineering', preference: 'vegetarian', submitted: true },
    { id: 4, name: 'Sarah Williams', department: 'HR', preference: 'non-vegetarian', submitted: true },
    { id: 5, name: 'Michael Brown', department: 'Finance', preference: 'no-meal', submitted: true },
    { id: 6, name: 'Jessica Davis', department: 'Sales', preference: 'vegetarian', submitted: true },
    { id: 7, name: 'Robert Wilson', department: 'Operations', preference: '', submitted: false },
    { id: 8, name: 'Lisa Miller', department: 'Engineering', preference: '', submitted: false }
  ]);
  
  const [vegCount, setVegCount] = useState(0);
  const [nonVegCount, setNonVegCount] = useState(0);
  const [noMealCount, setNoMealCount] = useState(0);
  const [totalSubmitted, setTotalSubmitted] = useState(0);
  const [totalEmployees, setTotalEmployees] = useState(0);
  
  // Calculate counts whenever employees state changes
  useEffect(() => {
    calculateCounts();
  }, [employees]);
  
  const calculateCounts = () => {
    setVegCount(employees.filter(emp => emp.preference === 'vegetarian').length);
    setNonVegCount(employees.filter(emp => emp.preference === 'non-vegetarian').length);
    setNoMealCount(employees.filter(emp => emp.preference === 'no-meal').length);
    setTotalSubmitted(employees.filter(emp => emp.submitted).length);
    setTotalEmployees(employees.length);
  };
  
  const editEmployee = (id, type) => {
    setEmployees(employees.map(emp => {
      if (emp.id === id) {
        return {
          ...emp,
          preference: type === 'veg' ? 'vegetarian' : type === 'non-veg' ? 'non-vegetarian' : 'no-meal',
          submitted: true
        };
      }
      return emp;
    }));
  };
  
  const submitToVendor = () => {
    // In a real application, this would send data to the backend
    toast({
      title: "Meal counts submitted",
      description: "The meal counts have been sent to the vendor.",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <DateTimeDisplay />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Client Admin Dashboard
            </h2>
          </div>
        </div>
        
        <div className="mt-6">
          <div className="bg-white shadow-sm rounded-lg overflow-hidden">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <h3 className="text-lg leading-6 font-medium text-gray-900">Employee Meal Counts</h3>
              <p className="mt-1 max-w-2xl text-sm text-gray-500">Review and edit employee meal selections for tomorrow.</p>
            </div>
            
            <div className="px-4 py-5 sm:p-6">
              <div className="mb-6 grid grid-cols-1 gap-5 sm:grid-cols-4">
                <div className="bg-white overflow-hidden shadow-sm rounded-md">
                  <div className="px-4 py-5 sm:p-6">
                    <dt className="text-sm font-medium text-gray-500 truncate">Vegetarian Meals</dt>
                    <dd className="mt-1 text-3xl font-semibold text-gray-900">{vegCount}</dd>
                  </div>
                </div>
                
                <div className="bg-white overflow-hidden shadow-sm rounded-md">
                  <div className="px-4 py-5 sm:p-6">
                    <dt className="text-sm font-medium text-gray-500 truncate">Non-Vegetarian Meals</dt>
                    <dd className="mt-1 text-3xl font-semibold text-gray-900">{nonVegCount}</dd>
                  </div>
                </div>
                
                <div className="bg-white overflow-hidden shadow-sm rounded-md">
                  <div className="px-4 py-5 sm:p-6">
                    <dt className="text-sm font-medium text-gray-500 truncate">No Meal</dt>
                    <dd className="mt-1 text-3xl font-semibold text-gray-900">{noMealCount}</dd>
                  </div>
                </div>
                
                <div className="bg-white overflow-hidden shadow-sm rounded-md">
                  <div className="px-4 py-5 sm:p-6">
                    <dt className="text-sm font-medium text-gray-500 truncate">Submission Rate</dt>
                    <dd className="mt-1 text-3xl font-semibold text-gray-900">
                      {Math.round((totalSubmitted / totalEmployees) * 100)}%
                    </dd>
                  </div>
                </div>
              </div>
              
              <div className="mb-6">
                <label htmlFor="recommendation" className="block text-sm font-medium text-gray-700">
                  Add Recommendation for Vendor
                </label>
                <div className="mt-1">
                  <Textarea
                    id="recommendation"
                    rows={3}
                    value={recommendation}
                    onChange={(e) => setRecommendation(e.target.value)}
                    placeholder="Add any special instructions or recommendations for the vendor..."
                    className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                  />
                </div>
              </div>
              
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Employee
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Department
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Preference
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {employees.map((employee) => (
                      <tr key={employee.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                              <span className="text-gray-600 font-medium">{employee.name.charAt(0)}</span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{employee.name}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{employee.department}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {employee.preference === 'vegetarian' && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Vegetarian
                            </span>
                          )}
                          {employee.preference === 'non-vegetarian' && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                              Non-Vegetarian
                            </span>
                          )}
                          {employee.preference === 'no-meal' && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                              No Meal
                            </span>
                          )}
                          {employee.preference === '' && (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                              Not Selected
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {employee.submitted ? (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Submitted
                            </span>
                          ) : (
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                              Pending
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex space-x-2">
                            <button 
                              onClick={() => editEmployee(employee.id, 'veg')}
                              className="text-green-600 hover:text-green-900 bg-green-50 rounded-md px-2 py-1"
                            >
                              Veg
                            </button>
                            <button 
                              onClick={() => editEmployee(employee.id, 'non-veg')}
                              className="text-red-600 hover:text-red-900 bg-red-50 rounded-md px-2 py-1"
                            >
                              Non-Veg
                            </button>
                            <button 
                              onClick={() => editEmployee(employee.id, 'no-meal')}
                              className="text-gray-600 hover:text-gray-900 bg-gray-50 rounded-md px-2 py-1"
                            >
                              No Meal
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-6">
                <Button 
                  onClick={submitToVendor}
                  className="inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Submit Finalized Counts to Vendor
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
