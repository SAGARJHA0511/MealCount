import { useState } from 'react';
import Navbar from '../components/Navbar';
import DateTimeDisplay from '../components/DateTimeDisplay';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

const VendorDashboard = () => {
  const { toast } = useToast();
  const [menuUploaded, setMenuUploaded] = useState(false);
  
  const uploadMenu = () => {
    setMenuUploaded(true);
    toast({
      title: "Menu Uploaded",
      description: "The weekly menu has been uploaded successfully.",
    });
    
    // Reset after 3 seconds
    setTimeout(() => {
      setMenuUploaded(false);
    }, 3000);
  };
  
  const printMealList = () => {
    // In a real app, this would generate a printable report
    toast({
      title: "Printing meal list",
      description: "The meal count list is being prepared for printing.",
    });
    
    // Here we would typically open a print dialog or generate a PDF
    window.print();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <DateTimeDisplay />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Vendor Dashboard
            </h2>
          </div>
        </div>
        
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          <div className="bg-white overflow-hidden shadow-sm rounded-md">
            <div className="px-4 py-5 sm:p-6">
              <dt className="text-sm font-medium text-gray-500 truncate">Total Vegetarian Meals</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">125</dd>
            </div>
          </div>
          
          <div className="bg-white overflow-hidden shadow-sm rounded-md">
            <div className="px-4 py-5 sm:p-6">
              <dt className="text-sm font-medium text-gray-500 truncate">Total Non-Vegetarian Meals</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">87</dd>
            </div>
          </div>
          
          <div className="bg-white overflow-hidden shadow-sm rounded-md">
            <div className="px-4 py-5 sm:p-6">
              <dt className="text-sm font-medium text-gray-500 truncate">Total Clients</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">3</dd>
            </div>
          </div>
        </div>
        
        <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-3">
          {/* Upload Weekly Menu Card */}
          <div className="sm:col-span-1">
            <div className="bg-white shadow-sm rounded-lg overflow-hidden">
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <h3 className="text-lg leading-6 font-medium text-gray-900">Upload Weekly Menu</h3>
              </div>
              <div className="px-4 py-5 sm:p-6">
                {!menuUploaded ? (
                  <>
                    <label className="block text-sm font-medium text-gray-700">Menu File</label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                      <div className="space-y-1 text-center">
                        <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                          <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                        <div className="flex text-sm text-gray-600">
                          <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-primary-600 hover:text-primary-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-primary-500">
                            <span>Upload menu file</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                          </label>
                          <p className="pl-1">or drag and drop</p>
                        </div>
                        <p className="text-xs text-gray-500">
                          PDF or Excel up to 10MB
                        </p>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <Button 
                        onClick={uploadMenu}
                        className="w-full inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                      >
                        Upload Menu
                      </Button>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <h3 className="mt-2 text-lg font-medium text-gray-900">Menu Uploaded!</h3>
                    <p className="mt-1 text-sm text-gray-500">
                      The weekly menu has been uploaded successfully.
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
          
          {/* View Feedback Card */}
          <div className="sm:col-span-2">
            <div className="bg-white shadow-sm rounded-lg overflow-hidden">
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <h3 className="text-lg leading-6 font-medium text-gray-900">Recent Feedback</h3>
              </div>
              <div className="px-4 py-5 sm:p-6">
                <div className="flow-root">
                  <ul role="list" className="-mb-8">
                    <li>
                      <div className="relative pb-8">
                        <div className="relative flex space-x-3">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                            <span className="text-gray-600 font-medium">J</span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div>
                              <div className="text-sm">
                                <span className="font-medium text-gray-900">John Smith</span>
                              </div>
                              <p className="mt-0.5 text-sm text-gray-500">
                                TechCorp Inc. • Yesterday
                              </p>
                              <div className="flex mt-1">
                                <span className="text-yellow-400">★★★★</span><span className="text-gray-300">★</span>
                              </div>
                            </div>
                            <div className="mt-2 text-sm text-gray-700">
                              <p>
                                The vegetarian pulao was excellent today! Would love to see more variety in the side dishes though.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    
                    <li>
                      <div className="relative pb-8">
                        <div className="relative flex space-x-3">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                            <span className="text-gray-600 font-medium">S</span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div>
                              <div className="text-sm">
                                <span className="font-medium text-gray-900">Sarah Williams</span>
                              </div>
                              <p className="mt-0.5 text-sm text-gray-500">
                                TechCorp Inc. • 2 days ago
                              </p>
                              <div className="flex mt-1">
                                <span className="text-yellow-400">★★★★★</span>
                              </div>
                            </div>
                            <div className="mt-2 text-sm text-gray-700">
                              <p>
                                The butter chicken was amazing! Perfect spice level and very tender chicken. Keep up the good work!
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                    
                    <li>
                      <div className="relative">
                        <div className="relative flex space-x-3">
                          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center">
                            <span className="text-gray-600 font-medium">D</span>
                          </div>
                          <div className="min-w-0 flex-1">
                            <div>
                              <div className="text-sm">
                                <span className="font-medium text-gray-900">David Lee</span>
                              </div>
                              <p className="mt-0.5 text-sm text-gray-500">
                                GlobalSoft • 3 days ago
                              </p>
                              <div className="flex mt-1">
                                <span className="text-yellow-400">★★★</span><span className="text-gray-300">★★</span>
                              </div>
                            </div>
                            <div className="mt-2 text-sm text-gray-700">
                              <p>
                                The dal makhani was a bit too salty today. Also, would appreciate if the naan could be served warmer.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                
                <div className="mt-4 text-center">
                  <Button 
                    variant="outline"
                    className="inline-flex justify-center py-2 px-4 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                  >
                    View All Feedback
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Meal Count List */}
        <div className="mt-6">
          <div className="bg-white shadow-sm rounded-lg overflow-hidden">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200 flex justify-between items-center">
              <div>
                <h3 className="text-lg leading-6 font-medium text-gray-900">Meal Count List</h3>
                <p className="mt-1 max-w-2xl text-sm text-gray-500">Meal orders for tomorrow.</p>
              </div>
              <Button 
                onClick={printMealList}
                className="inline-flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
                </svg>
                Print Meal List
              </Button>
            </div>
            <div className="px-4 py-5 sm:p-6">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Client
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Vegetarian
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Non-Vegetarian
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Total
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Special Requests
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">TechCorp Inc.</div>
                        <div className="text-sm text-gray-500">Software Company</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">58</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">42</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">100</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">5 gluten-free meals requested</div>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">GlobalSoft</div>
                        <div className="text-sm text-gray-500">IT Services</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">35</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">27</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">62</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">Extra spicy option requested for non-veg</div>
                      </td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm font-medium text-gray-900">NextGen Solutions</div>
                        <div className="text-sm text-gray-500">Consulting</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">32</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">18</div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <div className="text-sm text-gray-900">50</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-900">3 Jain meals (no onion/garlic)</div>
                      </td>
                    </tr>
                    <tr className="bg-gray-50">
                      <td className="px-6 py-4 whitespace-nowrap font-medium">
                        Total
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-medium">
                        125
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-medium">
                        87
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap font-medium">
                        212
                      </td>
                      <td className="px-6 py-4">
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VendorDashboard;
