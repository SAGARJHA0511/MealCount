import { useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Login from '../components/Auth/Login';
import RegisterVendor from '../components/Auth/RegisterVendor';
import RegisterClientAdmin from '../components/Auth/RegisterClientAdmin';
import RegisterEmployee from '../components/Auth/RegisterEmployee';

const Home = () => {
  const { isAuthenticated, userRole } = useAuth();
  const [currentView, setCurrentView] = useState('login');

  // If user is already authenticated, redirect to appropriate dashboard
  if (isAuthenticated) {
    return <Navigate to={`/dashboard/${userRole}`} replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8 bg-gray-50">
      {currentView === 'login' && (
        <Login onRegisterClick={(view) => setCurrentView(view)} />
      )}
      
      {currentView === 'registerVendor' && (
        <RegisterVendor onLoginClick={() => setCurrentView('login')} />
      )}
      
      {currentView === 'registerClientAdmin' && (
        <RegisterClientAdmin onLoginClick={() => setCurrentView('login')} />
      )}
      
      {currentView === 'registerEmployee' && (
        <RegisterEmployee onLoginClick={() => setCurrentView('login')} />
      )}
    </div>
  );
};

export default Home;
