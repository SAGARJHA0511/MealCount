/**
 * Checks if the current time is before 8 PM
 * @returns {boolean}
 */
export const isBefore8PM = () => {
  const now = new Date();
  return now.getHours() < 20;
};

/**
 * Generates a random 4-digit coupon code
 * @returns {string}
 */
export const generateCouponCode = () => {
  const digits = '0123456789';
  let code = '';
  for (let i = 0; i < 4; i++) {
    code += digits.charAt(Math.floor(Math.random() * digits.length));
  }
  return code;
};

/**
 * Formats a date object to YYYY-MM-DD string for input[type="date"]
 * @param {Date} date 
 * @returns {string}
 */
export const formatDateForInput = (date) => {
  const d = new Date(date);
  let month = '' + (d.getMonth() + 1);
  let day = '' + d.getDate();
  const year = d.getFullYear();

  if (month.length < 2) 
    month = '0' + month;
  if (day.length < 2) 
    day = '0' + day;

  return [year, month, day].join('-');
};
