import { useState } from 'react';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { isBefore8PM, generateCouponCode } from '../utils/helpers';

const MealCountForm = () => {
  const [mealPreference, setMealPreference] = useState('');
  const [couponGenerated, setCouponGenerated] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  
  const submitMeal = () => {
    if (mealPreference) {
      const code = generateCouponCode();
      setCouponCode(code);
      setCouponGenerated(true);
      
      // In a real app, this would send data to the backend
      console.log('Submitting meal preference:', mealPreference, 'Coupon:', code);
    }
  };
  
  const resetForm = () => {
    setMealPreference('');
    setCouponGenerated(false);
    setCouponCode('');
  };
  
  const beforeEightPM = isBefore8PM();

  return (
    <Card className="bg-white shadow-sm rounded-lg overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <CardTitle className="text-lg leading-6 font-medium text-gray-900">Meal Count Submission</CardTitle>
        <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500">Submit your meal preference for tomorrow.</CardDescription>
      </CardHeader>
      
      <CardContent className="px-4 py-5 sm:p-6">
        {!couponGenerated ? (
          <>
            {beforeEightPM ? (
              <div className="max-w-xl">
                <div className="space-y-6">
                  <div>
                    <div className="text-base font-medium text-gray-900">Meal Preference</div>
                    <p className="text-sm text-gray-500">Select your meal preference for tomorrow's lunch.</p>
                  </div>
                  
                  <RadioGroup value={mealPreference} onValueChange={setMealPreference}>
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <RadioGroupItem id="veg-desktop" value="vegetarian" />
                        <Label htmlFor="veg-desktop" className="ml-3 block text-sm font-medium text-gray-700">
                          Vegetarian
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <RadioGroupItem id="non-veg-desktop" value="non-vegetarian" />
                        <Label htmlFor="non-veg-desktop" className="ml-3 block text-sm font-medium text-gray-700">
                          Non-Vegetarian
                        </Label>
                      </div>
                      <div className="flex items-center">
                        <RadioGroupItem id="no-meal-desktop" value="no-meal" />
                        <Label htmlFor="no-meal-desktop" className="ml-3 block text-sm font-medium text-gray-700">
                          No Meal Required
                        </Label>
                      </div>
                    </div>
                  </RadioGroup>
                  
                  <div className="mt-6">
                    <Button
                      onClick={submitMeal}
                      disabled={!mealPreference}
                      className={`inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 ${
                        !mealPreference ? 'bg-gray-300 cursor-not-allowed' : 'bg-primary-600 hover:bg-primary-700'
                      }`}
                    >
                      Submit Meal Preference
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-6 max-w-xl">
                <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-2 text-lg font-medium text-gray-900">Meal Count Closed</h3>
                <p className="mt-1 text-sm text-gray-500">
                  Meal selection is only available before 8:00 PM. Please try again tomorrow.
                </p>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-6 max-w-xl">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900">Meal Preference Submitted!</h3>
            <p className="mt-1 text-sm text-gray-500">
              Your meal preference has been recorded.
            </p>
            <div className="mt-4">
              <p className="text-sm text-gray-500">Your Coupon Code:</p>
              <div className="mt-1 bg-gray-100 px-6 py-4 rounded-md inline-block">
                <span className="text-3xl font-bold tracking-wider text-gray-800">{couponCode}</span>
              </div>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              Present this code when collecting your meal tomorrow.
            </p>
            <div className="mt-4">
              <Button
                onClick={resetForm}
                variant="outline"
                className="inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Back to Meal Selection
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MealCountForm;
