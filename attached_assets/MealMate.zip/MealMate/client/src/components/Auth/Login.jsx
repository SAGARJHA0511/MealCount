import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useNavigate } from 'react-router-dom';

const Login = ({ onRegisterClick }) => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Login form submitted");
    setErrorMessage('');
    
    // Validate form inputs
    if (!email || !password) {
      setErrorMessage('Please enter both email and password');
      return;
    }
    
    // In a real app, this would validate credentials with an API
    // For now, we'll just simulate a successful login
    try {
      // Create a default demo user with the provided credentials
      const userData = { 
        username: email,
        password: password,
        name: email.split('@')[0], // Extract name from email
        role: 'client_employee' // Default role, would be determined by backend in real app
      };
      
      login(userData);
      
      // Manual navigation for guaranteed redirect
      setTimeout(() => {
        window.location.href = '/dashboard/client_employee';
      }, 500);
    } catch (error) {
      console.error("Login error:", error);
      setErrorMessage('An error occurred during login. Please try again.');
    }
  };
  
  const handleRoleSelection = (role) => {
    setErrorMessage('');
    if (!email || !password) {
      setErrorMessage('Please enter both email and password');
      return;
    }
    
    try {
      console.log("Logging in with role:", role);
      
      // Create a mock user with demo credentials
      const userData = { 
        username: email || 'demo@example.com',
        password: password || 'password123',
        name: 'Demo User',
        role: role
      };
      
      // Login user
      login(userData);
      
      // Manual navigation as fallback for better reliability
      setTimeout(() => {
        window.location.href = `/dashboard/${role}`;
      }, 500);
    } catch (error) {
      console.error("Login error:", error);
      setErrorMessage('An error occurred during login. Please try again.');
    }
  };

  return (
    <div className="max-w-md w-full space-y-8">
      <div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">MealTrack Pro</h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Corporate Meal Management System
        </p>
      </div>
      <div className="mt-8 bg-white py-8 px-4 shadow-lg sm:rounded-lg sm:px-10">
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Sign in to your account</h3>
          </div>
          
          {/* Error Message Display */}
          {errorMessage && (
            <div className="bg-red-50 border-l-4 border-red-400 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{errorMessage}</p>
                </div>
              </div>
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</Label>
              <div className="mt-1">
                <Input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="password" className="block text-sm font-medium text-gray-700">Password</Label>
              <div className="mt-1">
                <Input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <Label className="block text-sm font-medium text-gray-700">Select Role</Label>
              <div className="mt-1 grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div>
                  <Button
                    type="button"
                    onClick={() => handleRoleSelection('client_employee')}
                    className="w-full flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Employee
                  </Button>
                </div>
                <div>
                  <Button
                    type="button"
                    onClick={() => handleRoleSelection('client_admin')}
                    className="w-full flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Admin
                  </Button>
                </div>
                <div>
                  <Button
                    type="button"
                    onClick={() => handleRoleSelection('vendor')}
                    className="w-full flex items-center justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Vendor
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Checkbox
                  id="remember-me"
                  name="remember-me"
                  checked={rememberMe}
                  onCheckedChange={setRememberMe}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                />
                <Label
                  htmlFor="remember-me"
                  className="ml-2 block text-sm text-gray-900"
                >
                  Remember me
                </Label>
              </div>

              <div className="text-sm">
                <a href="#" className="font-medium text-blue-600 hover:text-blue-500">
                  Forgot your password?
                </a>
              </div>
            </div>

            {/* Login Button */}
            <div>
              <Button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                Sign in
              </Button>
            </div>

            <div className="pt-2">
              <div className="text-sm text-center">
                <span className="text-gray-500">Don't have an account?</span>
              </div>
              <div className="mt-3 grid grid-cols-1 gap-3">
                <div>
                  <Button
                    type="button"
                    onClick={() => onRegisterClick('registerVendor')}
                    variant="outline"
                    className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Register as Vendor
                  </Button>
                </div>
                <div>
                  <Button
                    type="button"
                    onClick={() => onRegisterClick('registerClientAdmin')}
                    variant="outline"
                    className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Register as Client Admin
                  </Button>
                </div>
                <div>
                  <Button
                    type="button"
                    onClick={() => onRegisterClick('registerEmployee')}
                    variant="outline"
                    className="w-full inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Register as Employee
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
