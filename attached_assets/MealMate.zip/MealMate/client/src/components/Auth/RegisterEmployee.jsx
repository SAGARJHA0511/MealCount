import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { useLocation } from 'wouter';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const RegisterEmployee = ({ onLoginClick }) => {
  const { register } = useAuth();
  const [location, setLocation] = useLocation();
  const [errorMessage, setErrorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    vendorId: '',
    fullName: '',
    email: '',
    password: '',
    department: 'Engineering',
    employeeId: '',
    terms: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleDepartmentChange = (value) => {
    setFormData({
      ...formData,
      department: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage('');
    console.log("Employee registration form submitted");
    
    if (formData.vendorId && formData.email && formData.password && formData.terms) {
      try {
        setIsSubmitting(true);
        console.log("Registering employee with data:", formData);
        
        // Register the user
        register({
          ...formData,
          username: formData.email,
        }, 'client_employee');
        
        // Use wouter for navigation
        setTimeout(() => {
          setLocation('/dashboard/client_employee');
        }, 300);
      } catch (error) {
        console.error("Registration error:", error);
        setErrorMessage('An error occurred during registration. Please try again.');
        setIsSubmitting(false);
      }
    } else {
      console.log("Validation failed:", { 
        vendorId: formData.vendorId, 
        email: formData.email, 
        password: formData.password, 
        terms: formData.terms 
      });
      setErrorMessage("Please fill all required fields and accept the terms");
    }
  };

  return (
    <div className="max-w-md w-full space-y-8">
      <div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">Register as Employee</h2>
      </div>
      <div className="mt-8 bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
        <div className="space-y-6">
          {/* Error Message Display */}
          {errorMessage && (
            <div className="bg-red-50 border-l-4 border-red-400 p-4">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-red-700">{errorMessage}</p>
                </div>
              </div>
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div>
              <Label htmlFor="vendor-id" className="block text-sm font-medium text-gray-700">Vendor ID</Label>
              <div className="mt-1">
                <Input
                  id="vendor-id"
                  name="vendorId"
                  type="text"
                  required
                  value={formData.vendorId}
                  onChange={handleChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="employee-name" className="block text-sm font-medium text-gray-700">Full Name</Label>
              <div className="mt-1">
                <Input
                  id="employee-name"
                  name="fullName"
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={handleChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="employee-email" className="block text-sm font-medium text-gray-700">Email</Label>
              <div className="mt-1">
                <Input
                  id="employee-email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="employee-password" className="block text-sm font-medium text-gray-700">Password</Label>
              <div className="mt-1">
                <Input
                  id="employee-password"
                  name="password"
                  type="password"
                  required
                  value={formData.password}
                  onChange={handleChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="employee-department" className="block text-sm font-medium text-gray-700">Department</Label>
              <div className="mt-1">
                <Select value={formData.department} onValueChange={handleDepartmentChange}>
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Engineering">Engineering</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                    <SelectItem value="Sales">Sales</SelectItem>
                    <SelectItem value="HR">HR</SelectItem>
                    <SelectItem value="Finance">Finance</SelectItem>
                    <SelectItem value="Operations">Operations</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="employee-id" className="block text-sm font-medium text-gray-700">Employee ID</Label>
              <div className="mt-1">
                <Input
                  id="employee-id"
                  name="employeeId"
                  type="text"
                  required
                  value={formData.employeeId}
                  onChange={handleChange}
                  className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <Checkbox
                id="employee-terms"
                name="terms"
                checked={formData.terms}
                onCheckedChange={(checked) => setFormData({...formData, terms: checked})}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <Label
                htmlFor="employee-terms"
                className="ml-2 block text-sm text-gray-900"
              >
                I agree to the <a href="#" className="text-primary-600 hover:text-primary-500">Terms and Conditions</a>
              </Label>
            </div>
            <div className="mt-6">
              <Button
                type="submit"
                disabled={isSubmitting}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                {isSubmitting ? 'Registering...' : 'Register'}
              </Button>
            </div>
            <div className="mt-4 text-sm text-center">
              <a onClick={onLoginClick} href="#" className="font-medium text-primary-600 hover:text-primary-500">
                Already have an account? Sign in
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default RegisterEmployee;
