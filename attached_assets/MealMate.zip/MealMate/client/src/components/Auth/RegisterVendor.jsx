import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useLocation } from 'wouter';

const RegisterVendor = ({ onLoginClick }) => {
  const { register, generateVendorId } = useAuth();
  const [location, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    companyName: '',
    email: '',
    password: '',
    phone: '',
    address: '',
    terms: false,
  });
  const [generatedVendorId, setGeneratedVendorId] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage('');
    console.log("Vendor registration form submitted");
    
    if (formData.companyName && formData.email && formData.password && formData.terms) {
      const vendorId = generateVendorId();
      setGeneratedVendorId(vendorId);
      setStep(2);
    } else {
      console.log("Validation failed:", { 
        companyName: formData.companyName, 
        email: formData.email, 
        password: formData.password, 
        terms: formData.terms 
      });
      setErrorMessage('Please fill in all required fields and accept the terms');
    }
  };

  const handleGoToDashboard = () => {
    try {
      setIsSubmitting(true);
      console.log("Going to dashboard with data:", {
        ...formData,
        vendorId: generatedVendorId
      });
      
      register({
        ...formData,
        username: formData.email,
        vendorId: generatedVendorId,
      }, 'vendor');
      
      // Use wouter for navigation
      setTimeout(() => {
        setLocation('/dashboard/vendor');
      }, 300);
    } catch (error) {
      console.error("Registration error:", error);
      setErrorMessage('An error occurred. Please try again.');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-md w-full space-y-8">
      <div>
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">Register as Vendor</h2>
      </div>
      <div className="mt-8 bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
        <div className="space-y-6">
          {/* Step 1: Registration Form */}
          {step === 1 && (
            <>
              {/* Error Message Display */}
              {errorMessage && (
                <div className="bg-red-50 border-l-4 border-red-400 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-red-700">{errorMessage}</p>
                    </div>
                  </div>
                </div>
              )}
            
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="company-name" className="block text-sm font-medium text-gray-700">Company Name</Label>
                  <div className="mt-1">
                    <Input
                      id="company-name"
                      name="companyName"
                      type="text"
                      required
                      value={formData.companyName}
                      onChange={handleChange}
                      className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="vendor-email" className="block text-sm font-medium text-gray-700">Email</Label>
                  <div className="mt-1">
                    <Input
                      id="vendor-email"
                      name="email"
                      type="email"
                      autoComplete="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="vendor-password" className="block text-sm font-medium text-gray-700">Password</Label>
                  <div className="mt-1">
                    <Input
                      id="vendor-password"
                      name="password"
                      type="password"
                      required
                      value={formData.password}
                      onChange={handleChange}
                      className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="vendor-phone" className="block text-sm font-medium text-gray-700">Phone Number</Label>
                  <div className="mt-1">
                    <Input
                      id="vendor-phone"
                      name="phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="vendor-address" className="block text-sm font-medium text-gray-700">Business Address</Label>
                  <div className="mt-1">
                    <Textarea
                      id="vendor-address"
                      name="address"
                      rows={3}
                      value={formData.address}
                      onChange={handleChange}
                      className="appearance-none block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                    />
                  </div>
                </div>
                <div className="flex items-center">
                  <Checkbox
                    id="terms"
                    name="terms"
                    checked={formData.terms}
                    onCheckedChange={(checked) => setFormData({...formData, terms: checked})}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <Label
                    htmlFor="terms"
                    className="ml-2 block text-sm text-gray-900"
                  >
                    I agree to the <a href="#" className="text-blue-600 hover:text-blue-500">Terms and Conditions</a>
                  </Label>
                </div>
                <div className="mt-6">
                  <Button
                    type="submit"
                    className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Register
                  </Button>
                </div>
              </form>
            </>
          )}

          {/* Step 2: Show Vendor ID */}
          {step === 2 && (
            <>
              {/* Error Message Display */}
              {errorMessage && (
                <div className="bg-red-50 border-l-4 border-red-400 p-4">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-red-400" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-red-700">{errorMessage}</p>
                    </div>
                  </div>
                </div>
              )}
            
              <div className="text-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-2 text-lg font-medium text-gray-900">Registration Successful!</h3>
                <div className="mt-4">
                  <p className="text-sm text-gray-500">Your Vendor ID is:</p>
                  <div className="mt-2 bg-gray-100 px-4 py-3 rounded-md">
                    <span className="text-lg font-medium text-gray-800">{generatedVendorId}</span>
                  </div>
                  <p className="mt-2 text-sm text-gray-500">
                    Share this ID with client admins for registration. Please save this ID for future reference.
                  </p>
                </div>
                <div className="mt-6">
                  <Button
                    onClick={handleGoToDashboard}
                    className="inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Go to Dashboard
                  </Button>
                </div>
              </div>
            </>
          )}

          <div className="text-sm text-center mt-4">
            <a onClick={onLoginClick} href="#" className="font-medium text-blue-600 hover:text-blue-500">
              Already have an account? Sign in
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterVendor;
