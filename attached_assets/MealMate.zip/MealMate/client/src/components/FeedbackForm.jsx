import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

const FeedbackForm = () => {
  const { toast } = useToast();
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [rating, setRating] = useState(0);
  
  const { register, handleSubmit, reset } = useForm({
    defaultValues: {
      mealDate: new Date().toISOString().split('T')[0],
      mealType: 'Vegetarian',
      comments: '',
      suggestions: ''
    }
  });
  
  const onSubmit = (data) => {
    // In a real app, this would send data to the backend
    console.log('Submitting feedback:', { ...data, rating });
    
    toast({
      title: "Feedback submitted",
      description: "Thank you for your feedback!",
    });
    
    setFeedbackSubmitted(true);
  };
  
  const submitAnotherFeedback = () => {
    setFeedbackSubmitted(false);
    setRating(0);
    reset();
  };

  return (
    <Card className="bg-white shadow-sm rounded-lg overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <CardTitle className="text-lg leading-6 font-medium text-gray-900">Feedback Form</CardTitle>
        <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500">Share your thoughts on our meal service.</CardDescription>
      </CardHeader>
      
      <CardContent className="px-4 py-5 sm:p-6">
        {!feedbackSubmitted ? (
          <form onSubmit={handleSubmit(onSubmit)} className="max-w-3xl">
            <div className="space-y-6">
              <div>
                <Label className="block text-sm font-medium text-gray-700 mb-1">Rating</Label>
                <div className="flex space-x-3">
                  {[1, 2, 3, 4, 5].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setRating(num)}
                      className={`h-10 w-10 rounded-full flex items-center justify-center ${
                        rating >= num 
                          ? 'bg-primary-500 text-white' 
                          : 'bg-gray-200 text-gray-400'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                <div className="sm:col-span-3">
                  <Label htmlFor="meal-date" className="block text-sm font-medium text-gray-700">Meal Date</Label>
                  <div className="mt-1">
                    <Input
                      id="meal-date"
                      type="date"
                      {...register('mealDate')}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="sm:col-span-3">
                  <Label htmlFor="meal-type" className="block text-sm font-medium text-gray-700">Meal Type</Label>
                  <div className="mt-1">
                    <select
                      id="meal-type"
                      {...register('mealType')}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    >
                      <option>Vegetarian</option>
                      <option>Non-Vegetarian</option>
                    </select>
                  </div>
                </div>
                
                <div className="sm:col-span-6">
                  <Label htmlFor="comments" className="block text-sm font-medium text-gray-700">Comments</Label>
                  <div className="mt-1">
                    <Textarea
                      id="comments"
                      rows={4}
                      placeholder="Please share your thoughts on today's meal..."
                      {...register('comments')}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
                
                <div className="sm:col-span-6">
                  <Label htmlFor="suggestions" className="block text-sm font-medium text-gray-700">Suggestions for Improvement</Label>
                  <div className="mt-1">
                    <Textarea
                      id="suggestions"
                      rows={3}
                      placeholder="Any suggestions for future meals..."
                      {...register('suggestions')}
                      className="shadow-sm focus:ring-primary-500 focus:border-primary-500 block w-full sm:text-sm border-gray-300 rounded-md"
                    />
                  </div>
                </div>
              </div>
              
              <div className="pt-5">
                <Button
                  type="submit"
                  className="inline-flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                >
                  Submit Feedback
                </Button>
              </div>
            </div>
          </form>
        ) : (
          <div className="text-center py-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="mx-auto h-12 w-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900">Thank You!</h3>
            <p className="mt-1 text-sm text-gray-500">
              Your feedback has been submitted successfully. We appreciate your input.
            </p>
            <div className="mt-4">
              <Button
                onClick={submitAnotherFeedback}
                variant="outline"
                className="inline-flex justify-center py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
              >
                Submit Another Feedback
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default FeedbackForm;
