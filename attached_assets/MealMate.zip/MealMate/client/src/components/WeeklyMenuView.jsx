import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';

const WeeklyMenuView = () => {
  const [activeDay, setActiveDay] = useState('monday');
  
  const menuData = {
    monday: [
      { type: 'vegetarian', name: 'Paneer Butter Masala', description: 'Cottage cheese cooked in rich tomato and butter gravy, served with naan.' },
      { type: 'non-vegetarian', name: 'Chicken Biryani', description: 'Fragrant basmati rice cooked with chicken and aromatic spices.' },
      { type: 'sides', name: 'Raita & Mixed Salad', description: 'Yogurt with cucumber and fresh seasonal salad.' }
    ],
    tuesday: [
      { type: 'vegetarian', name: 'Dal Makhani with Jeera Rice', description: 'Creamy black lentils simmered overnight, served with cumin rice.' },
      { type: 'non-vegetarian', name: 'Fish Curry', description: 'Fish fillet cooked in a tangy tomato-based curry with herbs.' },
      { type: 'dessert', name: 'Gulab Jamun', description: 'Sweet milk solid balls soaked in sugar syrup.' }
    ],
    wednesday: [
      { type: 'vegetarian', name: 'Veg Pulao', description: 'Fragrant rice cooked with mixed vegetables and mild spices.' },
      { type: 'non-vegetarian', name: 'Butter Chicken', description: 'Tender chicken in a creamy tomato sauce with butter and spices.' },
      { type: 'sides', name: 'Naan & Pickle', description: 'Freshly baked Indian bread and assorted pickles.' }
    ],
    thursday: [
      { type: 'vegetarian', name: 'Vegetable Korma', description: 'Mixed vegetables in a rich, creamy coconut curry.' },
      { type: 'non-vegetarian', name: 'Mutton Rogan Josh', description: 'Slow-cooked mutton in aromatic Kashmiri spices.' },
      { type: 'dessert', name: 'Fruit Custard', description: 'Sweet custard with mixed seasonal fruits.' }
    ],
    friday: [
      { type: 'vegetarian', name: 'Chole Bhature', description: 'Spiced chickpea curry served with fried bread.' },
      { type: 'non-vegetarian', name: 'Chicken Tikka Masala', description: 'Grilled chicken pieces in a spiced curry sauce.' },
      { type: 'sides', name: 'Pulao & Raita', description: 'Fragrant rice and yogurt with cucumber.' }
    ]
  };
  
  const getBadgeClass = (type) => {
    switch (type) {
      case 'vegetarian':
        return 'text-xs font-medium text-green-600 bg-green-100 px-2 py-1 rounded-full';
      case 'non-vegetarian':
        return 'text-xs font-medium text-red-600 bg-red-100 px-2 py-1 rounded-full';
      default:
        return 'text-xs font-medium text-gray-600 bg-gray-100 px-2 py-1 rounded-full';
    }
  };
  
  const renderMenuItems = (day) => {
    return menuData[day].map((item, index) => (
      <div key={index} className="border border-gray-200 rounded-lg p-4">
        <span className={getBadgeClass(item.type)}>
          {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
        </span>
        <h4 className="text-md font-medium text-gray-900 mt-2">{item.name}</h4>
        <p className="text-sm text-gray-500 mt-1">{item.description}</p>
      </div>
    ));
  };

  return (
    <Card className="bg-white shadow-sm rounded-lg overflow-hidden">
      <CardHeader className="px-4 py-5 sm:px-6 border-b border-gray-200">
        <CardTitle className="text-lg leading-6 font-medium text-gray-900">Weekly Menu</CardTitle>
        <CardDescription className="mt-1 max-w-2xl text-sm text-gray-500">View the menu for the current week.</CardDescription>
      </CardHeader>
      
      <CardContent className="px-4 py-5 sm:p-6">
        <Tabs value={activeDay} onValueChange={setActiveDay}>
          <TabsList className="border-b border-gray-200 mb-6 w-full overflow-x-auto">
            <TabsTrigger value="monday" className="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
              Monday
            </TabsTrigger>
            <TabsTrigger value="tuesday" className="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
              Tuesday
            </TabsTrigger>
            <TabsTrigger value="wednesday" className="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
              Wednesday
            </TabsTrigger>
            <TabsTrigger value="thursday" className="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
              Thursday
            </TabsTrigger>
            <TabsTrigger value="friday" className="whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm">
              Friday
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="monday" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {renderMenuItems('monday')}
            </div>
          </TabsContent>
          
          <TabsContent value="tuesday" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {renderMenuItems('tuesday')}
            </div>
          </TabsContent>
          
          <TabsContent value="wednesday" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {renderMenuItems('wednesday')}
            </div>
          </TabsContent>
          
          <TabsContent value="thursday" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {renderMenuItems('thursday')}
            </div>
          </TabsContent>
          
          <TabsContent value="friday" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {renderMenuItems('friday')}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default WeeklyMenuView;
