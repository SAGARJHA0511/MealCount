import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';

const DateTimeDisplay = () => {
  const [currentDate, setCurrentDate] = useState('');
  const [currentTime, setCurrentTime] = useState('');
  
  useEffect(() => {
    const updateDateTime = () => {
      const now = new Date();
      setCurrentDate(now.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      }));
      
      setCurrentTime(now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      }));
    };
    
    // Initial update
    updateDateTime();
    
    // Update time every minute
    const intervalId = setInterval(updateDateTime, 60000);
    
    // Cleanup
    return () => clearInterval(intervalId);
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
      <Card className="bg-white shadow-sm rounded-lg p-4 mb-4">
        <CardContent className="flex justify-between items-center p-0">
          <div className="text-sm font-medium text-gray-500">{currentDate}</div>
          <div className="text-sm font-medium text-gray-500">{currentTime}</div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DateTimeDisplay;
